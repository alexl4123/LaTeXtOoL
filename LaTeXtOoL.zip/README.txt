README
__________________________________________________________
For Licence, please Read: LICENCE.txt

This project is currently in the earliest stage of dev. .


The HTLaTeX/LaTeXtOoL is a Software created to 
make working with LaTeX easier.
In the final version it should can draw/print
mathematical functions, electric circuits,
tables, flow-diagramms / similar drawings.

to work:
download from Eclipse-Marketplace: e(fx)clipse

For further details or install from website:
http://www.eclipse.org/efxclipse/install.html
