package Draw;

import javafx.stage.Stage;

public class Drawing {
	public Drawing() throws Exception
	{
		DWindow DW = new DWindow();
		
		DW.start(new Stage());
	}
}
